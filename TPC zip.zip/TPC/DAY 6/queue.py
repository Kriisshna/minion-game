n=int(input())
p=int(input())
q=[6,7,8]
for i in range (n):
    d=int(input())
    q.append(d)
    print(q) 
    q.pop(0)
    print(q)
# print(q)
# for i in range (p):
#     q.pop(0)
# print(q)
