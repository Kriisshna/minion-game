a=int(input("enter the number:"))
print("Press 1 to check if a number is prime \nPress 2 to check if a number is even or odd \nPress 3 to check if a number is positive or negative ")
b=int(input)
if b=1:
    if a>1:
        