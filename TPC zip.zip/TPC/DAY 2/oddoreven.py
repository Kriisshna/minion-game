# a=int(input("enter the number"))
# if a&1==1:
#     print(a,"is an odd number")
# else:
#     print(a,"is an even number")