N=int(input("enter the range"))
sum=0
for i in range(N):
    sum+=i
    i=i+1
print("sum of numbers in range 0 to",N,"=",sum)