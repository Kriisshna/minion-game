for i in range(0,50):
   
    for j in range(i,50):   
        print(" ",end='')
    for j in range(i):
        print("^", end='')
    for j in range(i+1):
        print("^",end='')
    print()
for i in range(0,10):
    for j in range(0,25):
        print(" ",end='')
    for j in range(0,50):
        
        print("^", end='')
    print()