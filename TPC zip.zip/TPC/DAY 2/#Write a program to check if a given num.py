#Write a program to check if a given number is positive, negative, or zero.
a=int(input("enter the number"))      
if a>0:
    print(a,"is a positive number")
elif a<0:
    print(a,"is a negative number")
else
    print(a,"is zero")
