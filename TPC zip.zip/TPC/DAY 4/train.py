m=int(input())
a=['SU','L','M','U','L','M','U','SL']
print(a[m%8])
