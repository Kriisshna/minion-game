class encap:
    a=10
    print(a)
    def encapfuntion(self):
        print("encap function")
        print(self.a)

obj=encap()
obj.encapfuntion()
print(obj.a)
