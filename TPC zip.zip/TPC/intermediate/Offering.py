def god_offering(totlem):
    offering=[7]*3
    totalneeded=sum(offering)
    if totlem>totalneeded
        

lem=int(input())
god_offering()