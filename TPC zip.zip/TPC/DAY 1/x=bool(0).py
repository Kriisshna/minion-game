clear
a=12
b=3.12
print(a+b)
