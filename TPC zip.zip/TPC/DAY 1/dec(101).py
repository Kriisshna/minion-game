a=input("enter the binary number:")
b=int(a,2)
c=oct(b)
print("converted octal is ",c)

