a=int(input())
b=int(input())
c=int(input())
if a>b:
    if c>a:
        print(c,"is the greatest number")
    else:
        print(a,"is the greatest number")
else :
    if c>b:
        print(c,"is the greatest number")
    else:
        print(b,"is the greatest number")