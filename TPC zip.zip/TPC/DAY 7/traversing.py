class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
def Inorder(self):
    if root:
        Inorder(root.left)
        print(root.data,end='')
def Preorder(self):
    if root:
        print(root.data,end='')
        Preorder(root.left)
        Preorder(root.right)
    
root=Node(1)
root.left=Node(2)
root.right=Node(3)
root.left.left=Node(4)
root.left.right=Node(5)
print("pre order")
Preorder(root)
print()
# print("\n post order")
# Postorder(root)
# print()
# print("\n in order")
# Inorder(root)